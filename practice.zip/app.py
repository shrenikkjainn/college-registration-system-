from flask import Flask, redirect, url_for, session, request, Response, render_template
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secret"


# -------------------- LOGIN --------------------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("USERNAME")
        password = request.form.get("PASSWORD")

        if username == "admin" and password == "123":
            session["user"] = username
            return redirect(url_for("welcome"))
        else:
            return Response("Invalid Credentials", status=401)

    return '''
        <h2>Login Form</h2>
        <form method="POST">
            Username: <input type="text" name="USERNAME"><br><br>
            Password: <input type="password" name="PASSWORD"><br><br>
            <button type="submit">Login</button>
        </form>
    '''


# -------------------- WELCOME --------------------
@app.route("/welcome")
def welcome():
    if "user" in session:
        return f"""
        <h2>Welcome {session['user']}!</h2>
        <a href="{url_for('logout')}">Logout</a>
        """
    return redirect(url_for("login"))


# -------------------- LOGOUT --------------------
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


# -------------------- FEEDBACK FORM --------------------
@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    error = None
    success = None
    name = ""

    if request.method == 'POST':
        name = request.form.get('name', '')
        email = request.form.get('email', '')
        message = request.form.get('message', '')

        if not name or not email or not message:
            error = "All fields are required."
        elif "@" not in email:
            error = "Please enter a valid email address."
        else:
            print(name, email, message)
            success = "Thank you for your feedback!"

    return render_template('feedback.html', name=name, error=error, success=success)


# -------------------- JINJA FOR LOOP EXAMPLE --------------------
@app.route("/loop")
def loop():
    fruits = ["Apple", "Banana", "Mango", "Orange"]
    return render_template("loop.html", fruits=fruits)


# -------------------- JINJA IF-ELSE EXAMPLE --------------------
@app.route("/ifelse")
def ifelse():
    name = "Shrenik"     # Try None to test else
    marks = 82
    fruits = ["Apple", "Banana", "Mango"]

    return render_template(
        "ifelse.html",
        name=name,
        marks=marks,
        fruits=fruits
    )


# -------------------- JINJA VARIABLE EXAMPLE --------------------
@app.route("/home")
def home():
    return render_template(
        'jinja.html',
        name="Amit",
        current_time=datetime.now(),
        cart_items=["Laptop", "Mouse", "Keyboard"]
    )


# -------------------- MAIN --------------------
if __name__ == "__main__":
    app.run(debug=True)
